# VKI Farms Market Operations Platform

A full-stack field sales management system for VKI Farms, Benin City.

## Setup

1. Create a `.env` file in the root folder with:
```
REACT_APP_SUPABASE_URL=your_supabase_project_url
REACT_APP_SUPABASE_ANON_KEY=your_supabase_anon_key
```

2. Install dependencies:
```
npm install
```

3. Run locally:
```
npm start
```

## Deploy to Vercel

1. Push this repo to GitHub
2. Connect repo on vercel.com
3. Add environment variables in Vercel dashboard
4. Deploy

## Default Admin Login
- Username: `admin`
- Password: `vki2024admin`

**Change this password in Supabase after first login.**

## Features
- Master Portal (admin): Live dashboard, reports, rep management, pricing, messaging
- Rep Portal: POS sales flow, daily sessions, messages from head office
